<?php
header('Access-Control-Allow-Origin: *');
$con=mysqli_connect("localhost","id21878481_projectpilot","Project24@","id21878481_projectpilot");?>