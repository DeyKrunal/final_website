<?php
include_once("connection.php");
$response=array();
    $gsid = $_REQUEST['gsid'];
    
?>